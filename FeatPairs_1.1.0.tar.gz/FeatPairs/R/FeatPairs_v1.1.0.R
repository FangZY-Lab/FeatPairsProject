#Changes
#ctrl.method: add invar_abundance
#log_ratio: add log
#expand.ctrl: make optional
#EXAMPLE: res.fp_new_log_noexpand = FeatModPairs(counts=seu@assays$RNA$counts, logcounts=NULL, ctrl.method='invar_abundance', log_ratio=T, expand.ctrl=F, n.ctrl.feats=300, n.ctrl.mods=50, n.ctrl.nn=30, minsize.ctrl.mod=3, n.var.feats=2000, span=0.3, pca=T, pca.scale=T, adjust.modcount=F, adjust.dist.scale=F, use.snn=F, impute.ctrl.feats=F, impute.ctrl.mods=F, pca.dim1=1, pca.ndim=25, seed.pca=8888, seed.umap=8888)


#' @title Find Variable Features with Variance-Stabilizing Transformation
#'
#' @description This function takes a count matrix input and returns a statistics table for features ranked in the descending order of stabilized variances.
#'
#' @param x features by samples/cells
#' @param eps.var a small positive value for variance failed to be estimated
#' @param span parameter for lowess fitting
#'
#' @return A table for features ranked in the descending order of stabilized variances, with three columns: average, variance, stabilized variance.
#'
aux_find_variable_features_vst = function(x,eps.var=0.01,span=0.3){
	x.mean = rowMeans(x)
	x.vars = matrixStats::rowVars(x)
	x.vars.expected = predict(loess(x.vars~x.mean,span=span),x.mean)
	x.vars.expected[is.na(x.vars.expected)] = eps.var
	x.vars.expected[x.vars.expected<0] = eps.var
	x.stand = (x - x.mean)/sqrt(x.vars.expected) #x.vars.expected <- x.vars

	std.max = sqrt(ncol(x))*10 #possible extreme values, loosen from Seurat by 10 fold
	x.stand[x.stand > std.max] = std.max
	x.stand[x.stand < -std.max] = -std.max

	x.stand.vars = matrixStats::rowVars(x.stand) #x.stand.vars <- x
	o = order(x.stand.vars,decreasing=T)
	stat = cbind(mean=x.mean[o], var=x.vars[o], var.standardized = x.stand.vars[o])
	return(stat)
}

aux_top_abundant_invariable_features = function(x,eps.var=0.01,span=0.3){
	x.mean = rowMeans(x)
	x.vars = matrixStats::rowVars(x)
	x.vars.expected = predict(loess(x.vars~x.mean,span=span),x.mean)
	x.vars.expected[is.na(x.vars.expected)] = eps.var
	x.vars.expected[x.vars.expected<0] = eps.var
	x.mean2 = x.mean
	x.mean2[ which(x.vars > x.vars.expected) ] = NA
	o = order(x.mean2,decreasing=T,na.last=T)
	
	#remove those overdispersed
	o[o %in% which(x.vars > x.vars.expected)] = NA
	o = o[!is.na(o)]
	
	return(o)
}

aux_find_variable_features_ratio_blocked = function(counts, modcount, eps.cnt=0.1, adjust.modcount=FALSE, span=0.3, eps.var=0.01){
	block.size = as.integer(getOption("FeatPairs.ratio.block.size", 1000L))
	if(is.na(block.size) || block.size < 1L){
		block.size = 1000L
	}
	n.feats = nrow(counts)
	n.cells = ncol(counts)
	feat.names = rownames(counts)
	if(is.null(feat.names)){
		feat.names = as.character(seq_len(n.feats))
	}
	denom = modcount + eps.cnt
	scale.factor = if(adjust.modcount) mean(modcount) else 1
	x.mean = numeric(n.feats)
	x.vars = numeric(n.feats)
	block.starts = seq.int(1L, n.feats, by=block.size)
	for(start in block.starts){
		end = min(start + block.size - 1L, n.feats)
		inds = start:end
		ratio.block = t((t(counts[inds,,drop=FALSE]) + eps.cnt) / denom)
		if(adjust.modcount){
			ratio.block = ratio.block * scale.factor
		}
		x.mean[inds] = rowMeans(ratio.block)
		x.vars[inds] = matrixStats::rowVars(ratio.block)
		rm(ratio.block)
	}
	x.vars.expected = predict(loess(x.vars~x.mean,span=span),x.mean)
	x.vars.expected[is.na(x.vars.expected)] = eps.var
	x.vars.expected[x.vars.expected<0] = eps.var
	std.max = sqrt(n.cells)*10
	x.stand.vars = numeric(n.feats)
	for(start in block.starts){
		end = min(start + block.size - 1L, n.feats)
		inds = start:end
		ratio.block = t((t(counts[inds,,drop=FALSE]) + eps.cnt) / denom)
		if(adjust.modcount){
			ratio.block = ratio.block * scale.factor
		}
		x.stand = (ratio.block - x.mean[inds])/sqrt(x.vars.expected[inds])
		x.stand[x.stand > std.max] = std.max
		x.stand[x.stand < -std.max] = -std.max
		x.stand.vars[inds] = matrixStats::rowVars(x.stand)
		rm(ratio.block, x.stand)
	}
	o = order(x.stand.vars,decreasing=T)
	stat = cbind(mean=x.mean[o], var=x.vars[o], var.standardized = x.stand.vars[o])
	rownames(stat) = feat.names[o]
	return(stat)
}

aux_make_ratio_subset = function(counts, features, modcount, eps.cnt=0.1, adjust.modcount=FALSE){
	ratio = t((t(counts[features,,drop=FALSE]) + eps.cnt) / (modcount + eps.cnt))
	if(adjust.modcount){
		ratio = ratio * mean(modcount)
	}
	return(ratio)
}




#' @title Feature Pairs Method for a Count Data Matrix
#'
#' @description This function takes a count matrix input and returns a statistics table for features ranked in the descending order of stabilized variances.
#'
#' @param counts Raw count data (features x samples/cells), better after quality filtering in Seurat. Rare genes could be filtered before being used as input. Imputation is not necessary, though if already done set impute.ctrl.feats = FALSE and impute.ctrl.mods = FALSE.
#' @param logcounts Log (e base) transformed sequencing-depth-normalized counts
#' @param n.ctrl.feats Number of control features
#' @param n.ctrl.mods Number of control modules
#' @param ctrl.mods A list of control modules
#' @param n.ctrl.nn Number of nearest neighbours for each control feature as an extension
#' @param minsize.ctrl.mod Minimal size of a control module
#' @param n.var.feats Number of highly variable features to keep after obtaining feature pairs 
#' @param span Parameter for lowess fitting
#' @param adjust.modcount Logical, whether to perform a simple standardization of module counts to make the pair ratios based on different modules more comparable. If use.snn, they should become comparable anyway, so this adjustment is not needed (but still can be done, even though no impact on SNN).
#' @param adjust.dist.scale  Logical, whether to perform a rank-based standardization on distance matrices from pair ratios based on different control modules to make them more comparable in scale.
#' @param impute.ctrl.feats Logical, whether or not to perform imputation on control features. Since some ctrl features also have zeros, although pseudo counts will be added, an explicit imputation for the zeros might be helpful in some cases (with risk of distortion on the correlation structure of data).
#' @param impute.ctrl.mods Logical, whether or not to perform imputation on control modules. Might be needed in certain cases with very severe dropout so that still lots of 0s even in the summarized module count of these control modules.
#' @param method.impute Imputation method, either 'knn' or 'saver' 
#' @param pca Logical, whether perform PCA dimension reduction after obtaining feature pairs 
#' @param pca.ndim The dimensions of PCA to use 
#' @param pca.dim1 The start dimension of PCA to use, usually 1
#' @param pca.scale Logical, whether to perform scaling before PCA
#' @param use.snn Logical, whether generating shared nearest neighbour (SNN) networks
#' @param k.snn Number of k for kNN used by SNN. Seurat uses 20 as default. A larger k could also be used in terms of visualization smoothness.
#' @param k.impute Number of nearest-neighbour cells for imputation with kNN on features.
#' @param parallel Logical, whether to use parallel computing
#' @param eps.cnt The pseudocount added to data, e.g. 0.1 or 0.01
#' @param seed.pca Integer, random seed for PCA reproducibility
#' @param seed.umap Integer, random seed for UMAP reproducibility
#' @param ret.dist Logical, whether return the full distance matrix (often big)
#' @param ctrl.method Character, either 'abundance' or 'invar_abundance'.
#'
#' @return The return object contains the following components. ctrl.feats: control features, ctrl.mods: control modules, modcount: if impute.ctrl.mods is TRUE then return the imputed module counts, pc.list: list of first 50 PCs by each control module, pc.comb: final PCs combined from the pca.dim1:pca.ndim PCs by each control module, dist: full distance object (optional), umap: umap embedding, graph: nearest-neighbour graph (nn) and shared nearest-neighbour graph (snn), command: command of calling.
#' 
#' @examples
#' set.seed(1111)
#' num_genes <- 500
#' num_samples <- 30
#' counts <- matrix(stats::rpois(num_genes * num_samples, 
#'             lambda = 10), nrow = num_genes, ncol = num_samples)
#' rownames(counts) <- paste0("Gene_", 1:num_genes)
#' colnames(counts) <- paste0("Sample_", 1:num_samples)
#' res = FeatModPairs(counts)
#' @importFrom stats as.dist cutree loess predict
#' @importFrom utils head
#' 
#' @export
FeatModPairs = function(counts, logcounts=NULL, ctrl.method='abundance', log_ratio=FALSE, expand.ctrl=TRUE, n.ctrl.feats=100, n.ctrl.mods=20, ctrl.mods=NULL, n.ctrl.nn=30, minsize.ctrl.mod=3, n.var.feats=2000, span=0.3, adjust.modcount=TRUE, adjust.dist.scale=TRUE, impute.ctrl.feats=FALSE, impute.ctrl.mods=FALSE, method.impute='knn', pca=FALSE, pca.ndim=15, pca.dim1=1, pca.scale=FALSE, use.snn=FALSE, k.snn=50, k.impute=10, parallel=TRUE, eps.cnt=0.1, seed.pca=1111, seed.umap=2222, ret.dist=FALSE){
	if(adjust.dist.scale && use.snn){
		stop('Only one of adjust.dist.scale and use.snn can be TRUE.')
	}
	if(pca){
		if(adjust.dist.scale || use.snn){
			adjust.dist.scale = use.snn = FALSE
			warning('Since pca is TRUE, adjust.dist.scale & use.snn are set to FALSE.')
		}
	}
	if(impute.ctrl.feats && impute.ctrl.mods){
		stop('Either ctrl.feats or ctrl.mods could be imputed, you have specified both!')
	}
	if(!is.matrix(counts)){
		counts = data.matrix(counts)
	}
	if(is.null(logcounts)){
		logcounts = log(t(t(counts)/colSums(counts)*1e4) + 1)
	}else{
		if(!is.matrix(logcounts)){
			logcounts = data.matrix(logcounts)
		}
	}
	if(is.null(ctrl.mods)){
		if(ctrl.method=='abundance'){
			o = order(rowMeans(logcounts),decreasing=TRUE)
			inds.ctrl.feats = head(o,n.ctrl.feats)
		}
	else if(ctrl.method=='invar_abundance'){

        ## 只做 mean/var/iqr 的 rank，不做 PCA outlier 过滤

        x.mean = rowMeans(logcounts)
        x.var  = matrixStats::rowVars(logcounts)
        x.iqr  = matrixStats::rowIQRs(logcounts)

        # rank 越小越好
        r1 = rank(-x.mean, ties.method="average")
        r2 = rank(x.var,  ties.method="average")
        r3 = rank(x.iqr,  ties.method="average")

        score = 1.0*r1 + 1*r2 + 1*r3

        o = order(score)

        ## ---- 只做 rank 不做 PCA：直接取前 n.ctrl.feats ----
        inds.ctrl.feats = head(o, n.ctrl.feats)
    }


    # ============================================================

		if(expand.ctrl){
			#add ctrl genes' kNN genes
			message('Perform expansion of ctrl genes via kNN ...')
			dmat.ctrl_to_others = Rfast::dista(logcounts[inds.ctrl.feats,],logcounts)
			inds.ctrl.feats = union(inds.ctrl.feats, as.vector(apply(dmat.ctrl_to_others,1,function(x) head(order(x),n.ctrl.nn) )))
			message(sprintf('    %d new genes attracted by ctrl genes', length(inds.ctrl.feats)-n.ctrl.feats))
		}
	}else{
		impute.ctrl.feats = FALSE
		inds.ctrl.feats = match(unique(unlist(ctrl.mods)), rownames(counts))
		n.ctrl.mods = length(ctrl.mods)
	}
	#impute for zeros in ctrl feats (non-zero entries not changed)
	if(impute.ctrl.feats){
		message('Perform imputation on ctrl features ...')
		if(method.impute=='saver'){ #method: SAVER
			lib.sizes = colSums(counts)/1e4
			tX = log(t(counts[inds.ctrl.feats,])/lib.sizes + 1) #cell x gene
			#tX.imp = apply(tX,2,function(y){
			tX.imp = sapply(1:ncol(tX),function(j){
				y = tX[,j]
				#SAVER::expr.predict(x=tX, y=y)[[1]]
				SAVER::expr.predict(x=tX[,-j], y=y)[[1]]
			})
			#back to raw counts
			Xcnt.imp = t( (exp(tX.imp)-1) * lib.sizes )
			#replace 0s but keep other non-zero counts
			counts.ctrl.imp = ifelse(counts[inds.ctrl.feats,]>0, counts[inds.ctrl.feats,], Xcnt.imp) #no round() since imputed raw counts could be in 0~1
			rownames(counts.ctrl.imp) = as.character(inds.ctrl.feats)
		}else if(method.impute=='knn'){ #method: kNN
			lib.sizes = colSums(counts)/1e4
			tX = log(t(counts[inds.ctrl.feats,])/lib.sizes + 1) #cell x gene
			dmat.c = Rfast::Dist(tX)
			dimnames(dmat.c) = list(colnames(counts),colnames(counts))
			nnc.idx = t(apply(dmat.c,1,function(x){ head(x,k.impute+1)[-1] }))
			tX.imp = sapply(1:ncol(tX),function(j){
				y = tX[,j]
				if(any(y==0)){
					inds.0 = which(y==0)
					y[inds.0] = sapply(inds.0,function(ind){ mean(tX[nnc.idx[ind,], j]) })
					y
				}else{
					y
				}
			})
			#back to raw counts
			counts.ctrl.imp = t( (exp(tX.imp)-1) * lib.sizes )
			rownames(counts.ctrl.imp) = as.character(inds.ctrl.feats)
		}else{
			stop("method.impute must be one of: saver, knn")
		}
	}
	#get ctrl modules: use original data even impute.ctrl.feats == TRUE to avoid potential distortions caused by imputation
	if(!is.null(ctrl.mods)){
		message('Using given ctrl modules ...')
		#convert from genes to inds (character)
		ctrl.mods = lapply(ctrl.mods,function(x){ match(x,rownames(counts)) })
	}else{
		message('Get ctrl modules ...')
		# 先取出 ctrl 基因的 logcounts 子矩阵
    mat.ctrl <- logcounts[inds.ctrl.feats, , drop = FALSE]

    # 双重保险：剔掉含有 NA/NaN/Inf 的 ctrl 基因
    keep_rows <- apply(mat.ctrl, 1, function(z) all(is.finite(z)))
    if(any(!keep_rows)){
        n.bad <- sum(!keep_rows)
        warning(sprintf("Removed %d ctrl feats with non-finite values before hclust", n.bad))
        inds.ctrl.feats <- inds.ctrl.feats[keep_rows]
        mat.ctrl        <- mat.ctrl[keep_rows, , drop = FALSE]
    }

    # 如果删完太少，直接报错提示用户
    if(length(inds.ctrl.feats) < 5){
        stop("Too few valid ctrl.feats after removing non-finite rows; please check your data or ctrl.method settings.")
    }
		dmat.ctrl.feats = Rfast::Dist(logcounts[inds.ctrl.feats,],)
		hc.ctrl.feats = fastcluster::hclust(as.dist(dmat.ctrl.feats), method='ward.D2')
		cl.ctrl.feats = cutree(hc.ctrl.feats, n.ctrl.mods)
		ctrl.mods = tapply(inds.ctrl.feats, cl.ctrl.feats, c)
		ctrl.mods = ctrl.mods[sapply(ctrl.mods,length)>minsize.ctrl.mod]
		n.ctrl.mods = length(ctrl.mods) #update number of mods
	}
	out = list()
	#distances
	if(pca){
		dmat.integ = NULL
	}else{
		dmat.integ = matrix(0,ncol(counts),ncol(counts))
	}
	if(pca){
		#pc.comb = NULL
		out[['pc.list']] = list()
	}
	if(impute.ctrl.mods){
		modcounts = NULL
		modcounts.imp = NULL
	}
	for(i in 1:n.ctrl.mods){
		message(paste(i,paste(rownames(counts)[ctrl.mods[[i]]],collapse=',')))
		if(!impute.ctrl.feats && !impute.ctrl.mods){
			modcount = colSums(counts[ctrl.mods[[i]],])
		}else if(impute.ctrl.feats){
			modcount = colSums(counts.ctrl.imp[as.character(ctrl.mods[[i]]),])
		}else if(impute.ctrl.mods){
			message(sprintf('   Perform imputation on ctrl module %d ...',i))
			lib.sizes = colSums(counts)/1e4
			modcount = colSums(counts[ctrl.mods[[i]],])
			modcount.lognorm = log(modcount/lib.sizes + 1)
			tX = log(t(counts[inds.ctrl.feats,])/lib.sizes + 1) #cell x gene
			modcounts = rbind(modcounts, modcount)
			if(method.impute=='saver'){
				modcount.lognorm.pred = SAVER::expr.predict(x=tX, y=modcount.lognorm)[[1]]
				modcount.pred = (exp(modcount.lognorm.pred)-1) * lib.sizes
				modcount = ifelse(modcount>0, modcount, modcount.pred)
			}else if(method.impute=='knn'){
				#lib.sizes = colSums(counts)/1e4
				#modcount = colSums(counts[ctrl.mods[[i]],])
				#modcount.lognorm = log(modcount/lib.sizes + 1)
				#tX: only logcounts of ctrl.feats
				#tX = log(t(counts[inds.ctrl.feats,])/lib.sizes + 1) #cell x gene
				modcount.pred = modcount
				for(j in which(modcount==0)){
					idx = head(order(Rfast::dista(tX[j,,drop=F], tX, parallel=parallel)[1,]),k.impute+1)[-1]
					modcount.pred[j] = (exp(mean(modcount.lognorm[idx])) - 1) * lib.sizes[j]
				}
				modcount = ifelse(modcount>0, modcount, modcount.pred)
			}else{
				stop("method.impute must be one of: saver, knn")
			}
			modcounts.imp = rbind(modcounts.imp, modcount.pred)
		}else{
			stop('no such condition')
		}
		if(F){
			ratio.z = scale(ratio) 
		}
		#find variable features
		if(F){
			#stat.vst = aux_find_variable_features_vst(ratio.z,eps.var=0.01,std.max=10)
		}else{
			stat.vst = aux_find_variable_features_ratio_blocked(counts, modcount, eps.cnt=eps.cnt, adjust.modcount=adjust.modcount, span=span, eps.var=0.01)
		}
		var.feats = head(rownames(stat.vst),n.var.feats)
		ratio = aux_make_ratio_subset(counts, var.feats, modcount, eps.cnt=eps.cnt, adjust.modcount=adjust.modcount)
		#dmat = Rfast::Dist(t(scale(ratio)))
		if(log_ratio){
			ratio = log(ratio)
		}
		if(pca){
			set.seed(seed.pca)
			ratio.pca = irlba::prcomp_irlba(ratio, n=max(pca.ndim,50), center=TRUE, scale.=pca.scale) #column center
			if(F){
				dmat = Rfast::Dist(ratio.pca$rotation[,pca.dim1:pca.ndim])
			}else{
				#pc.comb = cbind(pc.comb, ratio.pca$rotation[,pca.dim1:pca.ndim])
				out[['pc.list']][[i]] = ratio.pca$rotation[,pca.dim1:pca.ndim,drop=FALSE] #[,pca.dim1:pca.ndim]
			}
		}else{
			if(F){
				dmat = Rfast::Dist(t(ratio.z[var.feats,]))
			}else if(T){
				dmat = Rfast::Dist(t(ratio))
			}
		}
		if(adjust.dist.scale){
			dmat = matrixStats::colRanks(dmat,ties.method='average',preserveShape=T)/nrow(dmat)
		}
		#SNN to automatically adjust to comparable scale
		if(use.snn){
			dmat = 1 - data.matrix(Seurat::FindNeighbors(dmat, distance.matrix=TRUE, nn.method = "annoy", k.param=k.snn, prune.SNN=0, return.neighbor=FALSE)$snn)
		}
		if(adjust.dist.scale || use.snn){
			dmat.integ = dmat.integ + dmat 
		}else if(!pca){
			dmat.integ = dmat.integ + log(dmat) 
		}
		rm(modcount, stat.vst, var.feats, ratio)
		if(exists("ratio.pca", inherits=FALSE)){ rm(ratio.pca) }
		if(exists("dmat", inherits=FALSE)){ rm(dmat) }
		gc()
		#res.umap = uwot::umap(as.dist(dmat))
	}
	if(adjust.dist.scale || use.snn){
		dmat.integ = dmat.integ/n.ctrl.feats 
	}else{
		dmat.integ = exp(dmat.integ/n.ctrl.feats) 
	}
	if(adjust.dist.scale){
		#from distance ranks, calculate Euclidean distance matrix
		dmat.integ = Rfast::Dist(dmat.integ)
	}
	if(pca){
		pc.comb = do.call(cbind, out[['pc.list']])
		keep_cols <- apply(pc.comb, 2, function(z) all(is.finite(z)))
    if(!all(keep_cols)){
        warning(sprintf(
            "Dropping %d PCs with non-finite values before Dist",
            sum(!keep_cols)
        ))
        pc.comb <- pc.comb[, keep_cols, drop = FALSE]
    }
		if(is.null(ctrl.mods)){
			#attr(dmat.integ, 'ctrl.feats') = rownames(counts)[inds.ctrl.feats]
			out[['ctrl.feats']] = rownames(counts)[inds.ctrl.feats]
		}
		#attr(dmat.integ, 'ctrl.mods') = lapply(ctrl.mods,function(inds) rownames(counts)[inds])
		out[['ctrl.mods']] = lapply(ctrl.mods,function(inds) rownames(counts)[inds])
		if(impute.ctrl.mods){
			#attr(dmat.integ, 'modcounts.imp') = modcounts.imp
			#attr(dmat.integ, 'modcounts') = modcounts
			out[[modcounts.imp]] = modcounts.imp
			out[['modcounts']] = modcounts
		}
		#attr(dmat.integ, 'pc.comb') = pc.comb
		#out[['pc.list']] = pc.list
		out[['pc.comb']] = pc.comb
		out[['command']] = sys.call(0)
		return(out)
	}

	diag(dmat.integ) = 0
	dimnames(dmat.integ) = list(colnames(counts),colnames(counts))

	#for use in integration with other datasets
	if(is.null(ctrl.mods)){
		#attr(dmat.integ, 'ctrl.feats') = rownames(counts)[inds.ctrl.feats]
		out[['ctrl.feats']] = rownames(counts)[inds.ctrl.feats]
	}
	#attr(dmat.integ, 'ctrl.mods') = lapply(ctrl.mods,function(inds) rownames(counts)[inds])
	out[['ctrl.mods']] = lapply(ctrl.mods,function(inds) rownames(counts)[inds])
	if(impute.ctrl.mods){
		#attr(dmat.integ, 'modcounts.imp') = modcounts.imp
		#attr(dmat.integ, 'modcounts') = modcounts
		out[[modcounts.imp]] = modcounts.imp
		out[['modcounts']] = modcounts
	}
	if(pca){
		#attr(dmat.integ, 'pc.comb') = pc.comb
		#out[['pc.list']] = pc.list
		out[['pc.comb']] = pc.comb
	}

	dist.integ = as.dist(dmat.integ)
	if(ret.dist){ out[['dist']] = dist.integ }
	res.umap = uwot::umap(dist.integ, seed=seed.umap)
	#attr(dmat.integ,'umap') = res.umap
	out[['umap']] = res.umap
	res.nn = Seurat::FindNeighbors(dist.integ,k.param = 20,prune.SNN = 1/15,n.trees = 50,nn.method = "rann",compute.SNN=TRUE) #rann is exact NN, not approximate
	out[['graph']] = res.nn
	out[['command']] = sys.call(0)
	return(out)
}







